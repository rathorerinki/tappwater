import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatSort } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { Router ,ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';
import { forkJoin } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { Title } from '@angular/platform-browser';

export interface data {
  Before: string;
  Substance: string;
  Limit_range: number;
  After: string;
}
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {


  data:any={};
  full_data:any=[];
  displayedColumns: string[] = ['Substance','Before','Limit_range','After' ];
  // dataSource = ELEMENT_DATA;
  // dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  dataSource:any;
  Chloramine: any ={};
  pH: any={};
  Calcium:any={};
  Microplastics:any={};
  Nitrates:any={};
  Bacteria_or_Viruses:any={};
  safe_water: boolean;
  dataSource_water_safety: Object;
  data_all: any=[];
  hold_array:any={};
  Chlorine_value: any;
  Chlorine_value_before_filtering: any;
  Hardness_value_before_filtering: any;
  Chlorine: any;
  Hardness: any;
  show_chlorie: boolean;
  pageTitle: string;
  table_hide: string;

  constructor(
        private router:Router,
        private apiservices:ApiService,
        private route:ActivatedRoute,
        private translate: TranslateService,
        public title: Title,
 ) {

    this.route.params.subscribe(params => {
          this.data['basic_details_id'] = params['id'];
          this.data['postcode'] = params['postcode'];
          this.data['id'] = params['id'];
        
    });


//  console.log(this.data['basic_details_id']);

   }

  ngOnInit(): void {

    this.translate.addLangs(['English', 'Spanish']);
    console.log(sessionStorage.getItem("pageTitle")=='Spanish' || sessionStorage.getItem("pageTitle")=='English')

    if(sessionStorage.getItem("pageTitle")=='Spanish' || sessionStorage.getItem("pageTitle")=='English'){

      let lang=sessionStorage.getItem("pageTitle");
      this.translate.use(lang);  
      console.log("1");
    }
    else{
      this.translate.addLangs(['English', 'Spanish']);
      this.translate.setDefaultLang('English');
  
      const browserLang = this.translate.getBrowserLang();
      this.translate.use(browserLang.match(/English|Spanish/) ? browserLang : 'English');
  
      console.log("2");
    }

    this.display();
  }

  setTheTitle(): void {
    this.title.setTitle(this.pageTitle);
    
  }

  function1(l,lang_data){
    console.log("pageTitle",lang_data)
    sessionStorage.removeItem("pageTitle")
    sessionStorage.setItem("pageTitle",lang_data)
  }

    async display(){

    this.dataSource = new MatTableDataSource();   
    await this.details();


   }

   async details(){
       
    await this.calculation();
   

  }
calculation(){

console.log("data",this.data)
const Water_safety=this.apiservices.postdata("water_safety_view",this.data)
const pathogens=this.apiservices.postdata("pathogens_data_view",this.data)
const general=this.apiservices.postdata("general_data_view",this.data)
const minerals_data_view=this.apiservices.postdata("minerals_data_view",this.data)
const Chemical_parameter_data_view=this.apiservices.postdata("Chemical_parameter_data_view",this.data);
const metals = this.apiservices.postdata("metals_data_view_priority",this.data);
// const pathogens = this.apiservices.postdata("pathogens_data_view_priority",this.data);
const select_details=this.apiservices.postdata("select_details",this.data)
const requestArray = [];

requestArray.push(Water_safety,general,minerals_data_view,Chemical_parameter_data_view,pathogens,metals,select_details);
  forkJoin(requestArray).subscribe(results => {


    console.log("here",results);
         if(!(results[0] && results[0].constructor === Array && Object.keys(results[0]).length === 0)){   
             for(let i=0;i<Object.keys(results[0]).length;i++){               
               if(results[0][i].Substance=='Free Chlorine'){
                console.log("Max",results[0][i])
                console.log("Recommended",results[0][i].Recommended =='')
                this.Chlorine_value_before_filtering=results[0][i].Zone; 
                 let note;
                if((results[1][i].Max >= results[0][i].Filtering)&&(results[0][i].Filtering > results[0][i].Recommended)) 
                 {
                  console.log("true condition",results[0][i].Max >= results[0][i].Filtering >= results[0][i].Recommended);
                  note="Within legal limit"
                }      
                else if(results[0][i].Filtering < results[0][i].Recommended){
                  note="Below legal limit"
                }
                else if(results[0][i].Filtering >results[0][i].Max){
                  note="Above legal limit"
                }
                if(results[3][i].Filtering==null){
                  note='Not reported'
                }
                this.data_all.push({Substance:'Chlorine', Before:results[0][i].Zone ,After:results[0][i].Filtering,Unit:results[0][i].Unit,max:results[0][i].Max,min:results[0][i].Recommended,note:note})   
                              
               }
               
             }
      }


      if(!(results[1] && results[1].constructor === Array && Object.keys(results[1]).length === 0)){   

            for(let i=0;i<Object.keys(results[1]).length;i++){

              if(results[1][i].Substance=='pH'){
                let note;
                console.log("max undefined..........",results[1][i].Max)
                console.log("recommented undefined...........",results[1][i].Recommended)
                if((results[1][i].Max >= results[1][i].Filtering)&&(results[1][i].Filtering > results[1][i].Recommended)) 
                 {
                  console.log("true condition",results[1][i].Max >= results[1][i].Filtering >= results[1][i].Recommended);
                  note="Within legal limit"
                }      
                else if(results[1][i].Filtering < results[1][i].Recommended){
                  note="Below legal limit"
                }
                else if(results[1][i].Filtering >results[1][i].Max){
                  note="Above legal limit"
                }
                if(results[3][i].Filtering==null){
                  note='Not reported'
                }
              this.dataSource.data=this.data_all.push({Substance:'pH', Before:results[1][i].Zone ,After:results[1][i].Filtering,Unit:results[1][i].Unit,max:results[1][i].Max,min:results[1][i].Recommended ,note:note})              
              }             

            if(results[1][i].Substance=='Microplastics'){
              this.data_all.push({Substance:'Microplastics', Before:results[1][i].Zone ,After:results[1][i].Filtering,Unit:results[1][i].Unit,max:results[1][i].Max,min:results[1][i].Recommended})

              
              

            }

            if(results[1][i].Substance=='Hardness'){
              let note;
              console.log("max undefined..........",results[1][i].Max)
              console.log("recommented undefined...........",results[1][i].Recommended)
              if((results[1][i].Max >= results[1][i].Filtering)&&(results[1][i].Filtering > results[1][i].Recommended)) 
               {
                console.log("true condition",results[1][i].Max >= results[1][i].Filtering >= results[1][i].Recommended);
                note="Within legal limit"
              }      
              else if(results[1][i].Filtering < results[1][i].Recommended){
                note="Below legal limit"
              }
              else if(results[1][i].Filtering >results[1][i].Max){
                note="Above legal limit"
              }
              if(results[3][i].Filtering==null){
                note='Not reported'
              }
              this.data_all.push({Substance:'Hardness', Before:results[1][i].Zone ,After:results[1][i].Filtering,Unit:results[1][i].Unit,max:results[1][i].Max,min:results[1][i].Recommended,note:note})
              this.Hardness_value_before_filtering=results[1][i].Zone;
            }
            // Hardness

          }
          
      }



      if(!(results[2] && results[2].constructor === Array && Object.keys(results[2]).length === 0)){ 
          for(let i=0;i<Object.keys(results[2]).length;i++){
            if(results[2][i].Substance=="Calcium"){    
              let note;
              console.log("max undefined..........",results[3][i].Max)
              console.log("recommented undefined...........",results[3][i].Recommended)
              if((results[3][i].Max >= results[3][i].Filtering)&&(results[3][i].Filtering > results[3][i].Recommended)) 
               {
                console.log("true condition",results[3][i].Max >= results[3][i].Filtering >= results[3][i].Recommended);
                note="Within legal limit"
              }      
              else if(results[3][i].Filtering < results[3][i].Recommended){
                note="Below legal limit"
              }
              else if(results[3][i].Filtering >results[3][i].Max){
                note="Above legal limit"
              }
              if(results[3][i].Filtering==null){
                note='Unregulated'
              }
            this.data_all.push({Substance:'Limescale', Before:results[2][i].Zone ,After:results[2][i].Filtering,Unit:results[2][i].Unit,max:results[2][i].Max,min:results[2][i].Recommended,note:note})

            }

          }
      }
        

      if(!(results[3] && results[3].constructor === Array && Object.keys(results[3]).length === 0)){   
        console.log("results[3]",results[3])
          for(let i=0;i<Object.keys(results[3]).length;i++){
            if(results[3][i].Substance=='Nitrates'){
              let note;
              console.log("max undefined..........",results[3][i].Max)
              console.log("recommented undefined...........",results[3][i].Recommended)
              if((results[3][i].Max >= results[3][i].Filtering)&&(results[3][i].Filtering > results[3][i].Recommended)) 
               {
                console.log("true condition",results[3][i].Max >= results[3][i].Filtering >= results[3][i].Recommended);
                note="Within legal limit"
              }      
              else if(results[3][i].Filtering < results[3][i].Recommended){
                note="Below legal limit"
              }
              else if(results[3][i].Filtering >results[3][i].Max){
                note="Above legal limit"
              }
              if(results[3][i].Filtering==null){
                note='Not reported'
              }
              console.log("results[3][i].Filtering",results[3][i].Filtering)

            this.data_all.push({Substance:'Nitrates', Before:results[3][i].Zone ,After:results[3][i].Filtering,Unit:results[3][i].Unit,max:results[3][i].Max,min:results[3][i].Recommended,note:note})                 
            }

          }      
       }

       if(!(results[4] && results[4].constructor === Array && Object.keys(results[4]).length === 0)){ 


        
        let subarray=[];
        let before=[];
        let after_value=[];
        let before_value;
        let after;

        var largest=0;
        var smallest=0;
          this.data_all.push({Substance:'Bacterias/virus', Before:"None reported" ,After:"None reported",Unit:"",max:largest,min:smallest,note:'None reported'}) 

       }

       if(!(results[5] && results[5].constructor === Array && Object.keys(results[5]).length === 0)){ 
        //  heavy metal
   
        let subarray=[];
        let before=[];
        let before_value;
        let after;
        let min=[]
        let after_value=[]
        for(let i=0;i<Object.keys(results[5]).length;i++){
           if(results[5][i].Substance=='Lead' ||results[5][i].Substance=='Manganese'||results[5][i].Substance=='Iron'||results[5][i].Substance=='Copper'||results[5][i].Substance=='Barium'||results[5][i].Substance=='Arsenic'){           
                before_value="Below limit";
                after="Safe level";
           }


         if(results[5][i].Substance=='Lead'){
            console.log("results[5][i]",results[5][i].Recommended=='' ,"fsdhfg")
             
              if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              }
          }
          if(results[5][i].Substance=='Manganese'){
            if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              } 
           }
          if(results[5][i].Substance=='Iron'){
            if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              }         

          }
          if(results[5][i].Substance=='Copper'){
            if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              }            
          }
          if(results[5][i].Substance=='Barium'){
            if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              } 

          }
          if(results[5][i].Substance=='Arsenic'){
            if(results[5][i].Max!=''){
              results[5][i].Max=parseFloat(results[5][i].Max);
              subarray.push(results[5][i].Max); }
              if(results[5][i].Recommended!=''){
              min.push(parseFloat(results[5][i].Recommended)); 
              }
          }

        }   


        console.log(min[0] !=undefined,"Nee")

  var largest=0;
         var smallest=0;
       
        this.data_all.push({Substance:'Heavy Metals', Before:before_value ,After:after,Unit:"",max:largest,min:smallest,note:'Below limit'})        
     }




       if(!(results[6] && results[6].constructor === Array && Object.keys(results[6]).length === 0)){   

        this.data['utlity_enter']=results[6]['utlity_enter'];
        this.data['city']=results[6]['city'];
        this.data['country']=results[6]['country'];
        this.data['description']=results[6]['description'];
        this.data['water']=results[6]['yes'];
        this.data['drinkable']=results[6]['drinkable']

     }
    


     
        this.hold_array.data=this.data_all;
         console.log("this.hold_array.data",this.hold_array.data)
          //  condition  for taste
          for(let i=0;i<this.data_all.length;i++){
          

            if(this.data_all[i].Substance=='Microplastics' ){                    
              // console.log("Microplastics",this.data_all[i])        
                if(this.data_all[i].Before==null||this.data_all[i].Before==undefined ||this.data_all[i].Before==''){
                  this.data_all[i].Before="Unknown";
                  this.data_all[i].note='Unregulated';
                }

                if(this.data_all[i].After==null||this.data_all[i].After==undefined ||this.data_all[i].After==''){
                  this.data_all[i].After;
                }
             }
                if(this.data_all[i].Substance=='Chlorine' ){                    
                    this.Chlorine=parseFloat(this.data_all[i].Before);
                                 
                if(results[0][i].Recommended>=results[0][i].Filtering<=results[0][i].Max){
                  console.log("here",results[0][i].Recommended>=results[0][i].Filtering<=results[0][i].Max)
              }

                }

                if(this.data_all[i].Substance=='Hardness'){
                    this.Hardness=parseFloat(this.data_all[i].Before);
                    // console.log("Hardness",this.data_all[i].Before);
                    
                }

                if(this.data_all[i].Substance=='Limescale'){
                  if(this.data_all[i].After==null){
                    console.log("this.data_all[i].After",this.data_all[i].After)
                  }
                  if(this.data_all[i].Before==null){
                    console.log("this.data_all[i].Before",this.data_all[i].Before)
                  }
                  if(this.data_all[i].Before!=null || this.data_all[i].After==null)
              {

                if(this.data_all[i].Before!=null){
                  this.data_all[i].Before=parseFloat(this.data_all[i].Before); 
                  if(this.data_all[i].Before>180 ){
                    this.data_all[i].Before="Very high";
                  }
                  if(this.data_all[i].Before<=180 && this.data_all[i].Before >=121){
                    this.data_all[i].Before="High";
                  }
                  if(this.data_all[i].Before<=120 && this.data_all[i].Before >=61){
                    this.data_all[i].Before="Medium";
                  }
                  if(this.data_all[i].Before <= 60){
                    this.data_all[i].Before="Low";
                  }
                }


                if(this.data_all[i].After!=null){
                  this.data_all[i].After=parseFloat(this.data_all[i].After);              

                    if(this.data_all[i].After>180){
                      this.data_all[i].After="Very high";
                    }
                    if(this.data_all[i].After<=180 && this.data_all[i].After >=121){
                      this.data_all[i].After="High";
                    }
                    if(this.data_all[i].After<=120 && this.data_all[i].After >=61){
                      this.data_all[i].After="Medium";
                    }
                    if(this.data_all[i].After <= 60){
                      this.data_all[i].After="Low";
                    }
                }
                  }

                    // console.log("i",this.data_all[i].After==NaN)
              }
              if(!(this.data_all[i].Substance=='Heavy Metals' || this.data_all[i].Substance=='Bacterias/virus')){
                this.data_all[i].After=parseFloat(this.data_all[i].After);   
                this.data_all[i].After=(this.data_all[i].After).toString()
                
              }

          }
         
          if(this.hold_array.data.length==0){
            this.table_hide="true";
          }
  });

  }
  check(){

  this.router.navigate(["/check",this.data['basic_details_id'],this.data['postcode']]).then(() => {
    // window.location.reload();
  });

  }
}


